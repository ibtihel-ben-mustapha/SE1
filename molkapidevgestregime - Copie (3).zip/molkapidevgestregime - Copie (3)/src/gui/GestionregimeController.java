/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.Objecttype;
import entities.Regime;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import services.Serviceregime;

/**
 * FXML Controller class
 *
 * @author Kardo
 */
public class GestionregimeController implements Initializable {

   
    @FXML
    private TextField txtnomreg;
    @FXML
    private TextField txtdescreg;
    @FXML
    private TextField txtduree;
    @FXML
    private TextField txtimcmax;
    @FXML
    private TextField txtimcmin;
    @FXML
    private DatePicker datepickreg;
    @FXML
    private ChoiceBox<Objecttype> choiceobj;
    
    
   
    /**
     * Initializes the controller class.
     */
     Serviceregime serviceRegime = new Serviceregime();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
     choiceobj.getItems().addAll(Objecttype.values());
     choiceobj.setValue(Objecttype.PERTEPOIDS);
    }    

    @FXML
    private void Ajouterreg(ActionEvent event) {
    String nom = txtnomreg.getText();
    String description = txtdescreg.getText();
    String imcMinStr = txtimcmin.getText();
    String imcMaxStr = txtimcmax.getText();
    
        if (nom.isEmpty() || description.isEmpty() || imcMinStr.isEmpty() || imcMaxStr.isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Champs obligatoires");
        alert.setHeaderText(null);
        alert.setContentText("Les champs 'Nom', 'Description', 'IMC min' et 'IMC max' sont obligatoires.");
        alert.showAndWait();}
        else {
    
    Objecttype objectType = choiceobj.getValue();
    String duree = txtduree.getText();
    Date date = java.sql.Date.valueOf(datepickreg.getValue());
    
    double imcMin = Double.parseDouble(txtimcmin.getText());
    double imcMax = Double.parseDouble(txtimcmax.getText());
  
    Regime regime = new Regime( 0,nom, description, objectType, duree, date, imcMin, imcMax);
     serviceRegime.ajouterregime(regime);
    
    }}

    @FXML
    private void retouracceuilregdeajout(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("affetsuppregime.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    } 
       
    }
    

    
    

