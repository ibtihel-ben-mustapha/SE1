/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.Objecttype;
import entities.Regime;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import services.Serviceregime;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Kardo
 */
public class ModifierregimeController implements Initializable {

    @FXML
    private TextField txtmodifnom;
    @FXML
    private TextField txtmodifdesc;
    @FXML
    private TextField txtmodifduree;
    @FXML
    private TextField txtimcminmodif;
    @FXML
    private TextField txtimcmaxmodif;
    @FXML
    private DatePicker pickdatemodif;
    @FXML
    private ChoiceBox<Objecttype> choiceobjmodif;
    @FXML
    private TextField txtidregrech;

    /**
     * Initializes the controller class.
     */Regime regimeToModify ;
     Serviceregime serviceRegime = new Serviceregime();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     choiceobjmodif.getItems().addAll(Objecttype.values());
     choiceobjmodif.setValue(Objecttype.PERTEPOIDS);
    }    
@FXML
    private void rechercherregparid(ActionEvent event) {
        String idStr = txtidregrech.getText();
        if (!idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            Serviceregime serviceRegime = new Serviceregime();
            Regime regime = serviceRegime.getRegimeParId( id);
            if (regime != null) {
                
                txtmodifnom.setText(regime.getNomreg());
                txtmodifdesc.setText(regime.getDescriptionreg());
                txtmodifduree.setText(regime.getDureereg());
                
                java.util.Date date = regime.getDatecreationreg();
                Instant instant = date.toInstant();
                ZoneId zoneId = ZoneId.systemDefault(); 
                 LocalDate localDate = instant.atZone(zoneId).toLocalDate();
                 pickdatemodif.setValue(localDate);
                 choiceobjmodif.setValue(regime.getObjectifreg());
                 txtimcminmodif.setText(String.valueOf(regime.getImcMin()));
                txtimcmaxmodif.setText(String.valueOf(regime.getImcMax()));
                
                regimeToModify = regime;
            } else {
               
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText(null);
                alert.setContentText("Aucun régime trouvé pour l'ID spécifié.");
                alert.showAndWait();
            }
        }
    }
    @FXML
    private void modifierreg(ActionEvent event) {
      
    
     if (regimeToModify != null) {
            // Récupération des nouvelles valeurs depuis les champs de texte
            String nom = txtmodifnom.getText();
            String description = txtmodifdesc.getText();
            String duree = txtmodifduree.getText();
            double imcMax = Double.parseDouble(txtimcmaxmodif.getText());
            double imcMin = Double.parseDouble(txtimcminmodif.getText());
           
            java.util.Date date = java.sql.Date.valueOf(pickdatemodif.getValue());
            Objecttype objectType = choiceobjmodif.getValue();

            
            regimeToModify.setNomreg(nom);
            regimeToModify.setDescriptionreg(description);
            regimeToModify.setDureereg(duree);
            regimeToModify.setObjectifreg(objectType);
            regimeToModify.setDateCreationreg(date);
            regimeToModify.setObjectifreg(objectType);
             regimeToModify.setImcMax(imcMax);
            regimeToModify.setImcMin(imcMin);

            // Appel de la méthode de modification
            serviceRegime.modifierregime(regimeToModify);

            

            // Réinitialisation de l'attribut regimeToModify
            regimeToModify = null;
        }

    
    
}

    @FXML
    private void retouracceuilregmodif(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("affetsuppregime.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    } 
    }



