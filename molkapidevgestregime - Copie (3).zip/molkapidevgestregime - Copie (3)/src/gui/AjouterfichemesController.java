/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.FicheMesures;
import entities.Typeactv;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import services.Servicefichemesures;

/**
 * FXML Controller class
 *
 * @author Kardo
 */
public class AjouterfichemesController implements Initializable {

    @FXML
    private TextField txttaille;
    @FXML
    private TextField txtpoids;
    @FXML
    private TextField txttourdetaille;
    @FXML
    private TextField txttourdehanches;
    @FXML
    private TextField txttourdepoitrine;
    @FXML
    private TextField txtmassegrasse;
    @FXML
    private TextField txtmassemusculaire;
  
    @FXML
    private DatePicker datepickfich;
    @FXML
    private ChoiceBox<Typeactv> choicenivactiv;
    @FXML
    private Label controletaille;
    @FXML
    private Label controlepoids;
 


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        choicenivactiv.getItems().addAll(Typeactv.values());
        choicenivactiv.setValue(Typeactv.SEDENTAIRE);
    }    
  
  

    @FXML
    private void ajouterfich(ActionEvent event) {
    String tailleText = txttaille.getText();
    String poidsText = txtpoids.getText();
    
        if (tailleText.isEmpty() || poidsText.isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Champs obligatoires");
        alert.setHeaderText(null);
        alert.setContentText("Les champs 'Taille' et 'Poids' sont obligatoires.");
        alert.showAndWait();}
        else {
        double taille = Double.parseDouble(txttaille.getText());
        double poids = Double.parseDouble(txtpoids.getText());
        double tourDeTaille = Double.parseDouble(txttourdetaille.getText());
        double tourDeHanches = Double.parseDouble(txttourdehanches.getText());
        double tourDePoitrine = Double.parseDouble(txttourdepoitrine.getText());
        double masseGrasse = Double.parseDouble(txtmassegrasse.getText());
        double masseMusculaire = Double.parseDouble(txtmassemusculaire.getText());
        Typeactv niveauActivite = choicenivactiv.getValue();
        FicheMesures ficheMesures = new FicheMesures(0, taille, poids, tourDeTaille, tourDeHanches, tourDePoitrine, masseGrasse, masseMusculaire, niveauActivite, java.sql.Date.valueOf(datepickfich.getValue()));
        Servicefichemesures serviceFicheMesures = new Servicefichemesures();
        serviceFicheMesures.ajouterfichmes(ficheMesures);}

    }
}


        

        
        
        
        
    
    
