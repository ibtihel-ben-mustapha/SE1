/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.Objecttype;
import javafx.scene.control.TextField;


import entities.Regime;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import services.Serviceregime;

import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Kardo
 */
public class AffetsuppregimeController implements Initializable {

   
    @FXML
    private TextField idregcherch;

    /**
     * Initializes the controller class.
     */
    private Serviceregime serviceRegime = new Serviceregime();
    private Regime regimeToBeDeleted; 
    @FXML
    private Button chercheridreg;
    @FXML
    private Button supprimeregime;
    @FXML
    private TableView<Regime> regimetv;
    @FXML
    private TableColumn<Regime, Integer> idregcol;
    @FXML
    private TableColumn<Regime, String> nomregcol;
    @FXML
    private TableColumn<Regime, String> descregcol;
    @FXML
    private TableColumn<Regime,  Objecttype> objregcol;
    @FXML
    private TableColumn<Regime, String> dureeregcol;
    @FXML
    private TableColumn<Regime, Date> dateregcol;
    @FXML
    private TableColumn<Regime, Double> imcmincol;
    @FXML
    private TableColumn<Regime, Double> imcmaxcol;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void chercheridreg(ActionEvent event) {
         String idStr = idregcherch.getText();
        if (!idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            regimeToBeDeleted = serviceRegime.getRegimeParId(id);
            if (regimeToBeDeleted != null) {
                // Vous pouvez afficher les détails du régime trouvé ici
                // Par exemple : System.out.println("Régime trouvé : " + regimeToBeDeleted.getNomreg());
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText(null);
                alert.setContentText("Aucun régime trouvé pour l'ID spécifié.");
                alert.showAndWait();
            }
        }
    }

    @FXML
    private void supprimeregime(ActionEvent event) {
         if (regimeToBeDeleted != null) {
            
             serviceRegime.supprimerregime(regimeToBeDeleted);
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText(null);
            alert.setContentText("Le régime a été supprimé avec succès.");
            alert.showAndWait();
            
           
            regimeToBeDeleted = null;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("Aucun régime à supprimer. Veuillez d'abord rechercher le régime.");
            alert.showAndWait();
        }
    }
@FXML
private void afficherregacceuil(ActionEvent event) {
    List<Regime> listeRegimes = serviceRegime.affihcerregime();
ObservableList<Regime> data = FXCollections.observableArrayList(listeRegimes);

    
    idregcol.setCellValueFactory(new PropertyValueFactory<>("idreg"));
    nomregcol.setCellValueFactory(new PropertyValueFactory<>("nomreg"));
    descregcol.setCellValueFactory(new PropertyValueFactory<>("descriptionreg"));
    objregcol.setCellValueFactory(new PropertyValueFactory<>("objectifreg"));
    dureeregcol.setCellValueFactory(new PropertyValueFactory<>("dureereg"));
    dateregcol.setCellValueFactory(new PropertyValueFactory<>("datecreationreg"));
    imcmincol.setCellValueFactory(new PropertyValueFactory<>("imcMin"));
    imcmaxcol.setCellValueFactory(new PropertyValueFactory<>("imcMax"));

    
    regimetv.setItems(data);
}

        
    
    @FXML
private void verspageajoutreg(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("gestionregime.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    } catch (IOException e) {
        e.printStackTrace();
    }
}


@FXML
private void verspagemodifreg(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("modifierregime.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    } catch (IOException e) {
        e.printStackTrace();
    }
}


   
}
    




    

   

    
