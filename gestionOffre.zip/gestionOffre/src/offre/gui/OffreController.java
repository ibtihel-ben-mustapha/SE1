/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package offre.gui;

import gestionoffre.offre;
import gestionoffre.serviceoffre;
import gestionoffre.typeoffre;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import static jdk.nashorn.internal.runtime.Debug.id;

/**
 * FXML Controller class
 *
 * @author jaafr
 */
public class OffreController implements Initializable {
       @FXML
    private Button btn;
    @FXML
    private TextField date;
    @FXML
    private ChoiceBox<String> type;
    @FXML
    private TextField nom;
    @FXML
    private TextField heure_debut;
    @FXML
    private TextField heure_fin;
    @FXML
    private TextField desc;
    @FXML
     private ObservableList<offre> offrelist = FXCollections.observableArrayList();
    private TextField prix;
    @FXML
    private ListView<offre> listo;
   


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadInitialDataFromDatabase();
        listo.setItems(offrelist);

        // TODO
    }    
     private void loadInitialDataFromDatabase() {
          serviceoffre so = new serviceoffre();
         List<offre> initialoffre = so.afficher();
    
    // Populate circuitList with the initial data from the database
    offrelist.clear();
     offrelist.addAll(initialoffre);
        type.getItems().addAll("coach","nutritionniste");
         type.setValue("coach");

 //  offrelist.addAll(initialoffre);
}
      @FXML
    private void ajouteroffre(ActionEvent event) {
          
             String n = nom.getText();
             String d = date.getText();
             String hd = heure_debut.getText();
             String hf = heure_fin.getText() ;
             int p=Integer.valueOf(prix.getText());
             String des = desc.getText();
             String v=type.getValue();
       typeoffre v = typeoffre.valueOf(type.getValue()); // Utilisation de TypeOffre au lieu de typeoffre

    serviceoffre so = new serviceoffre();
   offre o = new offre(n, d, hd, hf, p, des, v);
       so.ajouter(o); 
       List<offre> updatedCircuits = so.afficher();
            // Update circuitList with the new data
    offrelist.clear();
    offrelist.addAll(updatedCircuits);

    // Set the ListView items to circuitList to reflect the updated data
    listo.setItems(offrelist);

    // Clear the TextFields after saving
    clearTextFields();
} 
        private void modifier (ActionEvent event) {
   
    
    // Check if an item is selected
  
        String n = nom.getText();
             String d = date.getText();
             String hd = heure_debut.getText();
             String hf = heure_fin.getText() ;
             int p=Integer.valueOf(prix.getText());
             String des = desc.getText();
             String v=type.getValue();
             
             typeoffre v = typeoffre.valueOf(type.getValue()); // Utilisation de TypeOffre au lieu de typeoffre

         serviceoffre so = new serviceoffre();
   offre o = new offre(n, d, hd, hf, p, des, v);
        so.modifier(o);
            clearTextFields();
            List<offre> updatedCircuits = so.afficher();
            offrelist.clear();
    offrelist.addAll(updatedCircuits);
     // Refresh the ListView to reflect the changes
    listo.setItems(null); // Clear the items
    listo.setItems(offrelist); 
}
         @FXML
        private void supprimer (ActionEvent event) {
 offre selectedoffre = listo.getSelectionModel().getSelectedItem();

    // Check if an item is selected
    if (selectedoffre == null) {
        System.out.println("No item selected for deletion.");
        return;
    }

    // Remove the selected item from the database
    serviceoffre so = new serviceoffre();
    so.supprimer(selectedoffre);

    // Remove the selected item from the ListView
    offrelist.remove(selectedoffre);

    // Clear the TextFields after deleting
    clearTextFields();
                List<offre> updatedCircuits = so.afficher();
            offrelist.clear();
    offrelist.addAll(updatedCircuits);
     // Refresh the ListView to reflect the changes
    listo.setItems(null); // Clear the items
    listo.setItems(offrelist); 
}
@FXML
    private void clearTextFields() {
           nom.clear();
           date.clear();
           heure_debut.clear();
           heure_fin.clear();
          desc.clear();
          prix.clear();
}
}

        // TODO
        