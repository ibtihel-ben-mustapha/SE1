/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionoffre;

/**
 *
 * @author jaafr
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // offre o1 = new offre(13,"seance coaching","2030/12/2","14:00","15:00",30.0,"hhh", typeoffre.coach);     
      //System.out.println(o1); 
        //serviceoffre so = new serviceoffre();
         //so.ajouter(o1);
         //System.out.println(so.afficher());
        // TODO code application logic here
        reservation r1 = new reservation(13,30,11);   
        servicereservation sr = new servicereservation();
        System.out.println(r1);
       // sr.getreservationParId(13);
        System.out.println(sr.getreservationParId(13));
    }
    
    
}
