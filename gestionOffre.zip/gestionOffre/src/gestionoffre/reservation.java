/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionoffre;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author jaafr
 */
public class reservation {
     private int id_res ;
   private int  userId ; 
   private int id_offre ;
   

    public reservation() {
    }

    public reservation(int id_res, int userId ,int id_offre) {
        this.id_res = id_res;
        this.userId = userId;
        this.id_offre = id_offre;
        
    }

    public reservation( int userId ,int id_offre) {
          this.userId = userId;
        this.id_offre = id_offre;
    }

    public int getId_res() {
        return id_res;
    }

    public void setId_res(int id_res) {
        this.id_res = id_res;
    }

    public int getId_offre() {
        return id_offre;
    }

    public void setId_offre(int id_offre) {
        this.id_offre = id_offre;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

   
}
