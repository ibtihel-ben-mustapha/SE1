
 //* To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
 //*/
package gestionoffre;
import gestionoffre.typeoffre;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author jaafr
 */


 public class serviceoffre implements Iserviceoffre<offre> {
       typeoffre to;
   // ServiceTypeOffre  to = new ServiceTypeOffre();
   // User u;
    //UserService us = new UserService();
Connection cnx ;
Statement ste;
public serviceoffre(){
    
    cnx= database.getInstance().getConnection();
}
  
    public void ajouter(offre o) {
     try {
            String req = "insert into offre(id_offre,nom_offre,date_offre,heure_debut,heure_fin,prix,description,type)"
                    + " values (?,?,?,?,?,?,?,?)";
            PreparedStatement ste = cnx.prepareStatement(req);
             ste.setInt(1, o.getId_offre());
        ste.setString(2, o.getNom_offre());
        ste.setString(3, o.getDate_offre());
        ste.setString(4, o.getHeure_debut());
        ste.setString(5, o.getHeure_fin());
        ste.setDouble(6, o.getPrix());
        ste.setString(7, o.getDescription());

         // Convertissez l'énumération en une chaîne de caractères pour l'insérer dans la base de données
        ste.setString(8, o.getType().name());         
        
            ste.executeUpdate();
            System.out.println("offre ajoutée");
        } catch (SQLException ex) {
         
            System.out.println(ex.getMessage());
        }
}

    public void supprimer(offre o) {
        String sql = "delete from offre where id_offre=?";
        try {
            PreparedStatement ste = cnx.prepareStatement(sql);
            ste.setInt(1, o.getId_offre());
            ste.executeUpdate();

            System.out.println("offre supprimé");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        

    }

    @Override
    public void modifier(offre o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void supprimer(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<offre> getAll(offre o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      public void modifieroffre(offre o) {
        String sql = "update offre set nom_offre=?, Date_offre=?,heure_debut=?,heure_fin=? , prix=?, description=? where id_offre=? ";
        try {
            PreparedStatement ste = cnx.prepareStatement(sql);
            ste.setString(1, o.getNom_offre());
            ste.setString(2,  o.getDate_offre());
            ste.setString(3, o.getHeure_debut());
            ste.setString(4, o.getHeure_fin());
            ste.setDouble(5, o.getPrix());
            ste.setString(6, o.getDescription());
            ste.setInt(7, o.getId_offre());

            ste.executeUpdate();
            System.out.println("offre modifié");
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
      public List<offre> recuperer() throws SQLException {
    List<offre> listeOffres = new ArrayList<>();

    // Écrivez la requête SQL pour récupérer les offres
    String req = "SELECT idOffre, nomOffre, description, dateDebut, dateFin, typeOffre, valeurOffre, imageOffre, status, iduser FROM offre";

            PreparedStatement ste = cnx.prepareStatement(req);
    ResultSet rs = ste.executeQuery();

    while (rs.next()) {
        // Créez un nouvel objet Offre pour chaque enregistrement dans la base de données
        offre offre = new offre();
        offre.setId_offre(rs.getInt("Id_offre"));
        offre.setNom_offre(rs.getString("nom_offre"));
        offre.setDescription(rs.getString("description"));
        offre.setDate_offre(rs.getString("date_offre"));
        offre.setHeure_debut(rs.getString("heure_debut"));
        offre.setType(typeoffre.valueOf(rs.getString("type"))); // Vous devez avoir une méthode pour convertir une chaîne en enum TypeOffre
        // Créez un objet User si nécessaire et définissez-le dans l'offre
       

        // Ajoutez l'offre à la liste
        listeOffres.add(offre);
    }

    return listeOffres;
}
       /*public List<offre> afficher() {
       List<offre> offre = new ArrayList<>();
      String sql ="select * from offre";
       try {
            ste= cnx.createStatement();
            ResultSet rs = ste.executeQuery(sql);
          while(rs.next()){
              int id_offre = rs.getInt("id_offre");
    String nom_offre = rs.getString("nom_offre");
    String date_offre = rs.getString("date_offre");
    String heure_debut = rs.getString("heure_debut");
    String heure_fin = rs.getString("heure_fin");
    double prix = rs.getDouble("prix");
    String description = rs.getString("description");
    String type = rs.getString("type") ;
    // Récupérez la valeur de la colonne "type" sous forme de chaîne
   offre.settypeoffre(typeoffre.valueOf(rs.getString("type"))); 
//if ("nutritionniste".equals(typeString)) {
 //   typeoffre = typeoffre.nutritionniste;
//}
    // Convertissez la chaîne en une valeur d'énumération TypeOffre
   // String typeoffre = type.valueOf(typeString);

    // Créez un objet Offre avec les valeurs extraites
   offre o = new offre(id_offre, nom_offre, date_offre, heure_debut, heure_fin, prix, description, typeoffre);

           ////  Offre of = new Offre ( rs.getInt("id_offre"),
               //        rs.getString("nom_offre"),
                 //      rs.getString("date_offre"), 
                   //    rs.getString(4),
                     //  rs.getString(5),
                       //rs.getDouble(6),
              //         rs.getString("description"),
                //      rs.getString("type");
            
           
            offre.add(o);
           }
     } catch (SQLException ex) {
           System.out.println(ex.getMessage());
        }
        return offre;
    }*/
 
    /**
     *
     * @param t
     * @return
     
 /*  @Override
    public List<offre> getAll(offre t) {
      String req = "SELECT * FROM `offre`";
      ArrayList<offre> offres = new ArrayList();
    Statement stm; // Déclaration d'un objet Statement pour exécuter la requête SQL
    try {
        stm = this.cnx.createStatement();  // Création d'un objet Statement à partir de la connexion à la base de données
    
    
        ResultSet rs=  stm.executeQuery(req);
    while (rs.next()){                   // Parcourir les résultats de la requête
        offre o = new offre();           // Création d'un objet Offfre pour chaque enregistrement de la tabl
     //   o.setId_offre(rs.getInt(1));
       // o.setNom_offre(rs.getString("nom"));
       // o.setDate_offre(rs.getString("Date_offre"));
        //o.setHeure_debut(rs.getString("Heure_debut"));
     //   o.setHeure_fin(rs.getString("Heure_fin"));
   //     o.setPrix(rs.getDouble("Prix"));
 //       o.setDescription(rs.getString("Description"));
       // o.settype(rs.gettype(8));
       int idOffre = rs.getInt("id_offre");
    String nomOffre = rs.getString("nom_offre");
    String dateOffre = rs.getString("date_offre");
    String heureDebut = rs.getString("heure_debut");
    String heureFin = rs.getString("heure_fin");
    double prix = rs.getDouble("prix");
    String description = rs.getString("description");
    
    // Récupérez la valeur de la colonne "type" sous forme de chaîne
    String typeString = rs.getString("type");
    
    // Convertissez la chaîne en une valeur d'énumération TypeOffre
    TypeOffre typeOffre = TypeOffre.valueOf(typeString);

    // Créez un objet Offre avec les valeurs extraites
    
        offres.add(o);
    }
        
        
    } catch (SQLException ex) {
    
        System.out.println(ex.getMessage());
    
    }
    return offres;
    }*/
 }  
 

