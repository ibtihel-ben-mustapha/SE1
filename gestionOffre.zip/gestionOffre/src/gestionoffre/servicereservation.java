/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionoffre;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author jaafr
 */
public class servicereservation {
    Connection cnx ;
     Statement ste;

  public servicereservation(){
    this.cnx= database.getInstance().getConnection();
}  
  public void ajouter(reservation r) {
     try {
            String sql = "insert into reservation(id_res,id_user,id_offre)"
                    + " values (?,?,?)";
            PreparedStatement ste = cnx.prepareStatement(sql);
            ste.setInt(1, r.getId_res());
            ste.setInt(2, r.getUserId());
            ste.setInt(3, r.getId_offre());
          
        
           
           
            ste.executeUpdate();
            System.out.println("reservation ajoutée");
        } catch (SQLException ex) {
         
            System.out.println(ex.getMessage());
        }
}
  public void supprimer_res(reservation r) {
        String sql = "delete from reservation where id_res=?";
        try {
            PreparedStatement ste = cnx.prepareStatement(sql);
            ste.setInt(1, r.getId_res());
            ste.executeUpdate();
            System.out.println("Reservation supprimé");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
   
    public void modifier(reservation r) {
                try {
              
            String sql = "UPDATE reservation SET id_user = ?, id_offre = ? WHERE id_res = ?";

            PreparedStatement ste = cnx.prepareStatement(sql);
          
            ste.setInt(1, r.getUserId());
            ste.setInt(2, r.getId_offre());
            ste.setInt(3, r.getId_res());

            ste.executeUpdate();
            System.out.println("Reservation modifiée");
            
            
            
            } catch (SQLException ex) {
                System.out.println(ex);
            
        }}
        public reservation getreservationParId(int id) {
    String sql = "SELECT * FROM reservation WHERE id_res = ?";
    try {
        PreparedStatement pre = cnx.prepareStatement(sql);
        pre.setInt(1, id);
        ResultSet rs = pre.executeQuery();
        if (rs.next()) {
            int id_res = rs.getInt("id_res");
           int id_user = rs.getInt("userId");
           int id_offre= rs.getInt("id_offre");
            
            // Create and return a restaurant object with retrieved data
            return new reservation(id, id_user, id_offre);
        }
    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
    return null;
}

    }
    
  
